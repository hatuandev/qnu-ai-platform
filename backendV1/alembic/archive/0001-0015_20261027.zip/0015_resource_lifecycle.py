"""Reversible lifecycle, cancelled jobs and a separate serving revision; v1 tables only."""

import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

from alembic import op

revision = "0015_resource_lifecycle"
down_revision = "0014_operations"
branch_labels = None
depends_on = None

STATUS_CONSTRAINTS = (
    (
        "ocr_processing_runs",
        "ck_ocr_run_status",
        "status IN ('queued','running','completed','failed','uncertain','cancelled')",
    ),
    (
        "kb_compilation_runs",
        "ck_compilation_status",
        "status IN ('queued','running','completed','failed','uncertain','cancelled')",
    ),
    (
        "kb_index_runs",
        "ck_index_status",
        "status IN ('queued','running','completed','failed','uncertain','cancelled')",
    ),
    (
        "kb_compilation_review_jobs",
        "ck_compilation_review_job_status",
        "status IN ('queued','running','completed','failed','uncertain','cancelled')",
    ),
    (
        "kb_compilation_reviews",
        "ck_compilation_review_status",
        "status IN ('running','completed','failed','uncertain','cancelled')",
    ),
    (
        "ocr_spelling_runs",
        "ck_ocr_spelling_status",
        "status IN ('running','completed','failed','uncertain','cancelled')",
    ),
    (
        "chat_turns",
        "ck_chat_turn_status",
        "turn_no >= 1 AND status IN ('running','completed','failed','uncertain','cancelled')",
    ),
)


def upgrade():
    if {"resource_lifecycle_states", "resource_lifecycle_actions"}.intersection(
        sa.inspect(op.get_bind()).get_table_names()
    ):
        raise RuntimeError("Lifecycle tables already exist outside v1 history.")
    op.create_table(
        "resource_lifecycle_states",
        sa.Column(
            "workspace_id",
            sa.String(64),
            sa.ForeignKey("workspaces.id", ondelete="RESTRICT"),
            primary_key=True,
        ),
        sa.Column("kind", sa.String(24), primary_key=True),
        sa.Column("resource_id", sa.String(64), primary_key=True),
        sa.Column("status", sa.String(16), nullable=False),
        sa.Column("revision", sa.Integer(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint(
            "status IN ('active','archived','deleted')", name="ck_resource_lifecycle_status"
        ),
    )
    op.create_table(
        "resource_lifecycle_actions",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column(
            "workspace_id",
            sa.String(64),
            sa.ForeignKey("workspaces.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column("actor_ref", sa.String(200), nullable=False),
        sa.Column("kind", sa.String(24), nullable=False),
        sa.Column("resource_id", sa.String(64), nullable=False),
        sa.Column("action", sa.String(24), nullable=False),
        sa.Column("reason", sa.String(2000), nullable=False),
        sa.Column("parameters", postgresql.JSONB(), nullable=False),
        sa.Column("impact", postgresql.JSONB(), nullable=False),
        sa.Column("state_sha256", sa.String(64), nullable=False),
        sa.Column("preview_sha256", sa.String(64), nullable=False),
        sa.Column("status", sa.String(16), nullable=False),
        sa.Column("idempotency_key", sa.String(128)),
        sa.Column("request_hash", sa.String(64)),
        sa.Column("result", postgresql.JSONB()),
        sa.Column("error_code", sa.String(64)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("accepted_at", sa.DateTime(timezone=True)),
        sa.Column("finished_at", sa.DateTime(timezone=True)),
        sa.UniqueConstraint(
            "workspace_id", "actor_ref", "idempotency_key", name="uq_lifecycle_request"
        ),
        sa.CheckConstraint(
            "status IN ('preview','pending','completed','failed')",
            name="ck_lifecycle_action_status",
        ),
    )
    op.create_index(
        "ix_resource_lifecycle_actions_workspace_id", "resource_lifecycle_actions", ["workspace_id"]
    )
    op.add_column(
        "kb_sources",
        sa.Column("serving_revision_no", sa.Integer(), nullable=False, server_default="1"),
    )
    op.execute("UPDATE kb_sources SET serving_revision_no = latest_revision_no")
    op.create_check_constraint(
        "ck_source_serving_revision",
        "kb_sources",
        "serving_revision_no >= 1 AND serving_revision_no <= latest_revision_no",
    )
    for table, name, condition in STATUS_CONSTRAINTS:
        op.drop_constraint(name, table, type_="check")
        op.create_check_constraint(name, table, condition)


def downgrade():
    raise RuntimeError("Lifecycle evidence must be preserved; downgrade is disabled.")
