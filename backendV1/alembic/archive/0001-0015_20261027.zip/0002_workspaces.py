"""Workspace, membership and workspace audit tables (backendV1-owned)."""

from __future__ import annotations

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB

from alembic import context, op

revision = "0002_workspaces"
down_revision = "0001_baseline"
branch_labels = None
depends_on = None

V1_OWNED = ("workspaces", "workspace_members", "workspace_events")


def _existing_tables() -> set[str]:
    if context.is_offline_mode():
        return set()
    return set(sa.inspect(op.get_bind()).get_table_names())


def upgrade() -> None:
    existing = _existing_tables()
    if existing.intersection(V1_OWNED):
        raise RuntimeError("Workspace tables already exist outside the v1 migration history.")

    if "workspaces" not in existing:
        op.create_table(
            "workspaces",
            sa.Column("id", sa.String(64), primary_key=True),
            sa.Column("code", sa.String(64), nullable=False),
            sa.Column("name", sa.String(255), nullable=False),
            sa.Column("description", sa.Text(), nullable=True),
            sa.Column("status", sa.String(32), nullable=False, server_default="active"),
            sa.Column("created_by", sa.String(200), nullable=True),
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=sa.func.now(),
            ),
            sa.Column(
                "updated_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=sa.func.now(),
            ),
            sa.CheckConstraint("status IN ('active','suspended')", name="ck_workspace_status"),
        )
        op.create_index("ix_workspaces_code", "workspaces", ["code"], unique=True)
        op.create_index("ix_workspaces_status", "workspaces", ["status"])

    if "workspace_members" not in existing:
        op.create_table(
            "workspace_members",
            sa.Column("id", sa.String(64), primary_key=True),
            sa.Column(
                "workspace_id",
                sa.String(64),
                sa.ForeignKey("workspaces.id", ondelete="CASCADE"),
                nullable=False,
            ),
            sa.Column("actor_ref", sa.String(200), nullable=False),
            sa.Column("display_name", sa.String(255), nullable=True),
            sa.Column("role", sa.String(32), nullable=False, server_default="member"),
            sa.Column("status", sa.String(32), nullable=False, server_default="active"),
            sa.Column("invited_by", sa.String(200), nullable=True),
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=sa.func.now(),
            ),
            sa.Column(
                "updated_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=sa.func.now(),
            ),
            sa.UniqueConstraint("workspace_id", "actor_ref", name="uq_workspace_member"),
            sa.CheckConstraint(
                "role IN ('admin','editor','reviewer','member')", name="ck_member_role"
            ),
            sa.CheckConstraint("status IN ('active','pending','revoked')", name="ck_member_status"),
        )
        op.create_index("ix_workspace_members_workspace_id", "workspace_members", ["workspace_id"])
        op.create_index("ix_workspace_members_actor_ref", "workspace_members", ["actor_ref"])
        op.create_index("ix_workspace_members_status", "workspace_members", ["status"])

    if "workspace_events" not in existing:
        op.create_table(
            "workspace_events",
            sa.Column("id", sa.String(64), primary_key=True),
            sa.Column(
                "workspace_id",
                sa.String(64),
                sa.ForeignKey("workspaces.id", ondelete="CASCADE"),
                nullable=False,
            ),
            sa.Column("actor_ref", sa.String(200), nullable=True),
            sa.Column("action", sa.String(64), nullable=False),
            sa.Column("target_type", sa.String(64), nullable=True),
            sa.Column("target_id", sa.String(64), nullable=True),
            sa.Column("detail", JSONB(), nullable=False, server_default="{}"),
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=sa.func.now(),
            ),
        )
        op.create_index("ix_workspace_events_workspace_id", "workspace_events", ["workspace_id"])
        op.create_index("ix_workspace_events_action", "workspace_events", ["action"])
        op.create_index("ix_workspace_events_created_at", "workspace_events", ["created_at"])


def downgrade() -> None:
    """Keep governance data: membership and audit rows are not dropped."""
