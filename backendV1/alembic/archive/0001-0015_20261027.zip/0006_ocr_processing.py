"""OCR processing runs, page states and immutable artifacts (backendV1-owned).

Adds a composite unique key on ``kb_source_revisions`` so ``ocr_processing_runs`` can
reference a revision together with its source, collection and workspace. The three
new tables use the ``ocr_`` prefix but never reuse the legacy ``ocr_engines`` /
``ocr_job_logs`` names.
"""

from __future__ import annotations

import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

from alembic import context, op

revision = "0006_ocr_processing"
down_revision = "0005_knowledge_collections"
branch_labels = None
depends_on = None

V1_OWNED = ("ocr_processing_runs", "ocr_run_pages", "ocr_run_artifacts")


def _existing_tables() -> set[str]:
    if context.is_offline_mode():
        return set()
    return set(sa.inspect(op.get_bind()).get_table_names())


def _existing_constraints(table: str) -> set[str]:
    if context.is_offline_mode():
        return set()
    inspector = sa.inspect(op.get_bind())
    return {item["name"] for item in inspector.get_unique_constraints(table)}


def upgrade() -> None:
    existing = _existing_tables()
    if existing.intersection(V1_OWNED):
        raise RuntimeError("OCR tables already exist outside the v1 migration history.")
    if "kb_source_revisions" not in existing:
        raise RuntimeError("kb_source_revisions must exist before OCR processing tables.")

    if "uq_kb_revision_scope" not in _existing_constraints("kb_source_revisions"):
        op.create_unique_constraint(
            "uq_kb_revision_scope",
            "kb_source_revisions",
            ["id", "source_id", "collection_id", "workspace_id"],
        )

    op.create_table(
        "ocr_processing_runs",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("workspace_id", sa.String(64), nullable=False),
        sa.Column("collection_id", sa.String(64), nullable=False),
        sa.Column("source_id", sa.String(64), nullable=False),
        sa.Column("revision_id", sa.String(64), nullable=False),
        sa.Column("revision_no", sa.Integer(), nullable=False),
        sa.Column("source_sha256", sa.String(64), nullable=False),
        sa.Column("generation", sa.Integer(), nullable=False),
        sa.Column("status", sa.String(16), nullable=False, server_default="queued"),
        sa.Column("config", postgresql.JSONB(), nullable=False, server_default="{}"),
        sa.Column("config_fingerprint", sa.String(64), nullable=False),
        sa.Column("provider_id", sa.String(64), nullable=True),
        sa.Column("requested_by", sa.String(200), nullable=False),
        sa.Column(
            "requested_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()
        ),
        sa.Column("dispatched_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("pages_total", sa.Integer(), nullable=True),
        sa.Column("pages_done", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("pages_failed", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("attempt_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("max_attempts", sa.Integer(), nullable=False, server_default="2"),
        sa.Column("worker_id", sa.String(120), nullable=True),
        sa.Column("lease_expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("error_code", sa.String(64), nullable=True),
        sa.Column("error_detail", sa.String(500), nullable=True),
        sa.Column("usage_tokens", sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(
            ["revision_id", "source_id", "collection_id", "workspace_id"],
            [
                "kb_source_revisions.id",
                "kb_source_revisions.source_id",
                "kb_source_revisions.collection_id",
                "kb_source_revisions.workspace_id",
            ],
            name="fk_ocr_run_revision",
            ondelete="CASCADE",
        ),
        sa.UniqueConstraint("revision_id", "generation", name="uq_ocr_run_generation"),
        sa.CheckConstraint(
            "status IN ('queued','running','completed','failed','uncertain')",
            name="ck_ocr_run_status",
        ),
        sa.CheckConstraint("generation >= 1", name="ck_ocr_run_generation"),
        sa.CheckConstraint(
            "pages_done >= 0 AND pages_failed >= 0 AND attempt_count >= 0",
            name="ck_ocr_run_counters",
        ),
        sa.CheckConstraint("char_length(source_sha256) = 64", name="ck_ocr_run_sha256"),
    )
    op.create_index("ix_ocr_processing_runs_workspace_id", "ocr_processing_runs", ["workspace_id"])
    op.create_index("ix_ocr_processing_runs_revision_id", "ocr_processing_runs", ["revision_id"])
    op.create_index("ix_ocr_processing_runs_status", "ocr_processing_runs", ["status"])
    op.create_index(
        "ix_ocr_runs_workspace_status", "ocr_processing_runs", ["workspace_id", "status"]
    )
    op.create_index(
        "uq_ocr_run_active",
        "ocr_processing_runs",
        ["revision_id"],
        unique=True,
        postgresql_where=sa.text("status IN ('queued','running')"),
    )

    op.create_table(
        "ocr_run_pages",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column(
            "run_id",
            sa.String(64),
            sa.ForeignKey("ocr_processing_runs.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("page_number", sa.Integer(), nullable=False),
        sa.Column("status", sa.String(16), nullable=False, server_default="pending"),
        sa.Column("image_key", sa.String(512), nullable=True),
        sa.Column("image_sha256", sa.String(64), nullable=True),
        sa.Column("width", sa.Integer(), nullable=True),
        sa.Column("height", sa.Integer(), nullable=True),
        sa.Column("raw_key", sa.String(512), nullable=True),
        sa.Column("raw_sha256", sa.String(64), nullable=True),
        sa.Column("text", sa.Text(), nullable=True),
        sa.Column("blocks_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("has_tables", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("error_code", sa.String(64), nullable=True),
        sa.Column("attempts", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("usage_tokens", sa.Integer(), nullable=True),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()
        ),
        sa.UniqueConstraint("run_id", "page_number", name="uq_ocr_page_number"),
        sa.CheckConstraint("page_number >= 1", name="ck_ocr_page_number"),
        sa.CheckConstraint(
            "status IN ('pending','in_flight','completed','blank','failed','uncertain')",
            name="ck_ocr_page_status",
        ),
        sa.CheckConstraint("attempts >= 0", name="ck_ocr_page_attempts"),
    )
    op.create_index("ix_ocr_run_pages_run_id", "ocr_run_pages", ["run_id"])

    op.create_table(
        "ocr_run_artifacts",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column(
            "run_id",
            sa.String(64),
            sa.ForeignKey("ocr_processing_runs.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("kind", sa.String(24), nullable=False),
        sa.Column("page_no", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("blob_key", sa.String(512), nullable=False),
        sa.Column("sha256", sa.String(64), nullable=False),
        sa.Column("size_bytes", sa.Integer(), nullable=False),
        sa.Column("content_type", sa.String(120), nullable=False),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()
        ),
        sa.UniqueConstraint("run_id", "kind", "page_no", name="uq_ocr_artifact_kind_page"),
        sa.CheckConstraint(
            "kind IN ('render_pdf','page_image','raw_response','canonical_json','markdown','manifest')",
            name="ck_ocr_artifact_kind",
        ),
        sa.CheckConstraint("page_no >= 0", name="ck_ocr_artifact_page"),
        sa.CheckConstraint("size_bytes > 0", name="ck_ocr_artifact_size"),
        sa.CheckConstraint("char_length(sha256) = 64", name="ck_ocr_artifact_sha256"),
    )
    op.create_index("ix_ocr_run_artifacts_run_id", "ocr_run_artifacts", ["run_id"])


def downgrade() -> None:
    """Keep OCR evidence: raw responses and derived artifacts are never dropped here."""
    raise RuntimeError(
        "OCR evidence must be preserved; downgrade requires an explicit rollback plan."
    )
