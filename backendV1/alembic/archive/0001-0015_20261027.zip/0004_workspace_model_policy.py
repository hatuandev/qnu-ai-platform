"""Capability defaults, workspace quotas and observed usage ledger."""

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB

from alembic import op

revision = "0004_workspace_model_policy"
down_revision = "0003_modelops"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "modelops_events",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("actor_ref", sa.String(200), nullable=False),
        sa.Column("action", sa.String(64), nullable=False),
        sa.Column("provider_id", sa.String(64), nullable=True),
        sa.Column("detail", JSONB(), nullable=False),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()
        ),
    )
    op.create_table(
        "workspace_model_defaults",
        sa.Column("workspace_id", sa.String(64), primary_key=True),
        sa.Column("capability", sa.String(16), primary_key=True),
        sa.Column("provider_id", sa.String(64), nullable=False),
        sa.ForeignKeyConstraint(
            ["workspace_id", "provider_id"],
            ["workspace_allowed_providers.workspace_id", "workspace_allowed_providers.provider_id"],
            ondelete="CASCADE",
        ),
        sa.CheckConstraint(
            "capability IN ('chat','embedding','rerank','ocr')",
            name="ck_workspace_default_capability",
        ),
    )
    op.create_table(
        "workspace_quotas",
        sa.Column(
            "workspace_id",
            sa.String(64),
            sa.ForeignKey("workspaces.id", ondelete="RESTRICT"),
            primary_key=True,
        ),
        sa.Column("month_period", sa.Date(), primary_key=True),
        sa.Column("monthly_token_limit", sa.BigInteger(), nullable=True),
        sa.Column("tokens_used", sa.BigInteger(), nullable=False, server_default="0"),
        sa.Column("tokens_reserved", sa.BigInteger(), nullable=False, server_default="0"),
        sa.Column("is_blocked", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()
        ),
        sa.CheckConstraint(
            "monthly_token_limit IS NULL OR monthly_token_limit >= 0", name="ck_quota_limit"
        ),
        sa.CheckConstraint("tokens_used >= 0 AND tokens_reserved >= 0", name="ck_quota_counters"),
    )
    op.create_table(
        "model_usage_records",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column(
            "workspace_id",
            sa.String(64),
            sa.ForeignKey("workspaces.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column(
            "provider_id",
            sa.String(64),
            sa.ForeignKey("providers.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column("actor_ref", sa.String(200), nullable=False),
        sa.Column("request_id", sa.String(128), nullable=False),
        sa.Column("request_hash", sa.String(64), nullable=False),
        sa.Column("capability", sa.String(16), nullable=False),
        sa.Column("model_name", sa.String(200), nullable=False),
        sa.Column("month_period", sa.Date(), nullable=False),
        sa.Column("reserved_tokens", sa.BigInteger(), nullable=False),
        sa.Column("total_tokens", sa.BigInteger(), nullable=True),
        sa.Column("cost_usd", sa.Numeric(20, 8), nullable=True),
        sa.Column("status", sa.String(16), nullable=False, server_default="reserved"),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()
        ),
        sa.UniqueConstraint("workspace_id", "request_id", name="uq_model_usage_request"),
        sa.CheckConstraint(
            "status IN ('reserved','completed','failed','unknown')", name="ck_model_usage_status"
        ),
        sa.CheckConstraint(
            "reserved_tokens > 0 AND (total_tokens IS NULL OR total_tokens >= 0)",
            name="ck_model_usage_tokens",
        ),
        sa.CheckConstraint("cost_usd IS NULL OR cost_usd >= 0", name="ck_model_usage_cost"),
    )
    op.create_index("ix_model_usage_records_workspace_id", "model_usage_records", ["workspace_id"])


def downgrade() -> None:
    raise RuntimeError("Usage/quota history requires an explicit data-preserving rollback plan.")
