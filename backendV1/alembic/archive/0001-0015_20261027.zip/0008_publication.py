"""Compiled versions, preview receipts and publication lifecycle (v1-owned)."""

from __future__ import annotations

import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

from alembic import op

revision = "0008_publication"
down_revision = "0007_compilation"
branch_labels = None
depends_on = None


def upgrade() -> None:
    existing = set(sa.inspect(op.get_bind()).get_table_names())
    if existing.intersection(
        {
            "kb_compiled_documents",
            "kb_compiled_versions",
            "kb_publication_previews",
            "kb_publication_decisions",
        }
    ):
        raise RuntimeError("Publication tables already exist outside the v1 migration history.")
    op.create_table(
        "kb_compiled_documents",
        sa.Column("id", sa.String(length=64), nullable=False),
        sa.Column("workspace_id", sa.String(length=64), nullable=False),
        sa.Column("collection_id", sa.String(length=64), nullable=False),
        sa.Column("document_key", sa.String(length=120), nullable=False),
        sa.Column("title", sa.String(length=255), nullable=False),
        sa.Column("change_sequence", sa.Integer(), nullable=False),
        sa.Column("created_by", sa.String(length=200), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint("change_sequence >= 1", name="ck_compiled_document_sequence"),
        sa.ForeignKeyConstraint(
            ["collection_id", "workspace_id"],
            ["kb_collections.id", "kb_collections.workspace_id"],
            name="fk_compiled_document_collection",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "id", "workspace_id", "collection_id", name="uq_compiled_document_scope"
        ),
        sa.UniqueConstraint(
            "workspace_id", "collection_id", "document_key", name="uq_compiled_document_key"
        ),
    )
    op.create_table(
        "kb_compiled_versions",
        sa.Column("id", sa.String(length=64), nullable=False),
        sa.Column("document_id", sa.String(length=64), nullable=False),
        sa.Column("workspace_id", sa.String(length=64), nullable=False),
        sa.Column("collection_id", sa.String(length=64), nullable=False),
        sa.Column("compilation_run_id", sa.String(length=64), nullable=False),
        sa.Column("version_no", sa.Integer(), nullable=False),
        sa.Column("status", sa.String(length=16), nullable=False),
        sa.Column("state_version", sa.Integer(), nullable=False),
        sa.Column("input_sha256", sa.String(length=64), nullable=False),
        sa.Column("draft_sha256", sa.String(length=64), nullable=False),
        sa.Column("markdown_sha256", sa.String(length=64), nullable=False),
        sa.Column("bundle_sha256", sa.String(length=64), nullable=False),
        sa.Column("provenance", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("created_by", sa.String(length=200), nullable=False),
        sa.Column("idempotency_key", sa.String(length=128), nullable=False),
        sa.Column("request_hash", sa.String(length=64), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint(
            "status IN ('draft','approved','published','superseded','withdrawn')",
            name="ck_compiled_version_status",
        ),
        sa.CheckConstraint(
            "version_no >= 1 AND state_version >= 1", name="ck_compiled_version_sequence"
        ),
        sa.ForeignKeyConstraint(
            ["compilation_run_id", "workspace_id", "collection_id"],
            [
                "kb_compilation_runs.id",
                "kb_compilation_runs.workspace_id",
                "kb_compilation_runs.collection_id",
            ],
            name="fk_compiled_version_run",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["document_id", "workspace_id", "collection_id"],
            [
                "kb_compiled_documents.id",
                "kb_compiled_documents.workspace_id",
                "kb_compiled_documents.collection_id",
            ],
            name="fk_compiled_version_document",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("compilation_run_id", name="uq_compiled_version_run"),
        sa.UniqueConstraint("document_id", "version_no", name="uq_compiled_version_no"),
        sa.UniqueConstraint(
            "id", "document_id", "workspace_id", "collection_id", name="uq_compiled_version_scope"
        ),
        sa.UniqueConstraint(
            "workspace_id", "created_by", "idempotency_key", name="uq_compiled_registration"
        ),
    )
    op.create_index(
        op.f("ix_kb_compiled_versions_document_id"),
        "kb_compiled_versions",
        ["document_id"],
        unique=False,
    )
    op.create_index(
        "uq_compiled_document_published",
        "kb_compiled_versions",
        ["document_id"],
        unique=True,
        postgresql_where=sa.text("status = 'published'"),
    )
    op.create_table(
        "kb_publication_previews",
        sa.Column("id", sa.String(length=64), nullable=False),
        sa.Column("version_id", sa.String(length=64), nullable=False),
        sa.Column("document_id", sa.String(length=64), nullable=False),
        sa.Column("workspace_id", sa.String(length=64), nullable=False),
        sa.Column("collection_id", sa.String(length=64), nullable=False),
        sa.Column("actor_ref", sa.String(length=200), nullable=False),
        sa.Column("action", sa.String(length=16), nullable=False),
        sa.Column("reason", sa.String(length=1000), nullable=False),
        sa.Column("expected_document_sequence", sa.Integer(), nullable=False),
        sa.Column("expected_version_sequence", sa.Integer(), nullable=False),
        sa.Column("expected_active_version_id", sa.String(length=64), nullable=True),
        sa.Column("bundle_sha256", sa.String(length=64), nullable=False),
        sa.Column("preview_sha256", sa.String(length=64), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint(
            "action IN ('approve','publish','withdraw')", name="ck_publication_preview_action"
        ),
        sa.ForeignKeyConstraint(
            ["version_id", "document_id", "workspace_id", "collection_id"],
            [
                "kb_compiled_versions.id",
                "kb_compiled_versions.document_id",
                "kb_compiled_versions.workspace_id",
                "kb_compiled_versions.collection_id",
            ],
            name="fk_publication_preview_version",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "id",
            "version_id",
            "document_id",
            "workspace_id",
            "collection_id",
            name="uq_publication_preview_scope",
        ),
    )
    op.create_table(
        "kb_publication_decisions",
        sa.Column("id", sa.String(length=64), nullable=False),
        sa.Column("preview_id", sa.String(length=64), nullable=False),
        sa.Column("version_id", sa.String(length=64), nullable=False),
        sa.Column("document_id", sa.String(length=64), nullable=False),
        sa.Column("workspace_id", sa.String(length=64), nullable=False),
        sa.Column("collection_id", sa.String(length=64), nullable=False),
        sa.Column("actor_ref", sa.String(length=200), nullable=False),
        sa.Column("action", sa.String(length=16), nullable=False),
        sa.Column("reason", sa.String(length=1000), nullable=False),
        sa.Column("idempotency_key", sa.String(length=128), nullable=False),
        sa.Column("request_hash", sa.String(length=64), nullable=False),
        sa.Column("document_sequence", sa.Integer(), nullable=False),
        sa.Column("bundle_sha256", sa.String(length=64), nullable=False),
        sa.Column("before", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("after", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint(
            "action IN ('approve','publish','withdraw')", name="ck_publication_decision_action"
        ),
        sa.ForeignKeyConstraint(
            ["preview_id", "version_id", "document_id", "workspace_id", "collection_id"],
            [
                "kb_publication_previews.id",
                "kb_publication_previews.version_id",
                "kb_publication_previews.document_id",
                "kb_publication_previews.workspace_id",
                "kb_publication_previews.collection_id",
            ],
            name="fk_publication_decision_preview",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "document_id", "document_sequence", name="uq_publication_decision_sequence"
        ),
        sa.UniqueConstraint("preview_id", name="uq_publication_decision_preview"),
        sa.UniqueConstraint(
            "workspace_id", "actor_ref", "idempotency_key", name="uq_publication_decision_request"
        ),
    )
    op.create_index(
        op.f("ix_kb_publication_decisions_document_id"),
        "kb_publication_decisions",
        ["document_id"],
        unique=False,
    )


def downgrade() -> None:
    raise RuntimeError(
        "Publication evidence must be preserved; downgrade requires an explicit rollback plan."
    )
