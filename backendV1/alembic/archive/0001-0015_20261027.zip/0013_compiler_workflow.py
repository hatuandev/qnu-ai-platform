"""Pin corrected OCR inputs, review outbox and immutable accepted draft amendments.

DDL is frozen here; it never imports live application models during migration.
"""

import sqlalchemy as sa

from alembic import op

revision = "0013_compiler_workflow"
down_revision = "0012_compiler_review"
branch_labels = None
depends_on = None


def upgrade() -> None:
    existing = set(sa.inspect(op.get_bind()).get_table_names())
    if existing.intersection({"kb_compilation_review_jobs", "kb_compilation_edit_previews"}):
        raise RuntimeError("Compiler workflow tables already exist outside v1 history.")
    op.add_column("kb_compilation_runs", sa.Column("parent_run_id", sa.String(64)))
    op.add_column(
        "kb_compilation_runs",
        sa.Column("origin", sa.String(16), nullable=False, server_default="model"),
    )
    op.create_foreign_key(
        "fk_compilation_parent",
        "kb_compilation_runs",
        "kb_compilation_runs",
        ["parent_run_id", "workspace_id", "collection_id"],
        ["id", "workspace_id", "collection_id"],
        ondelete="RESTRICT",
    )
    op.create_check_constraint(
        "ck_compilation_origin", "kb_compilation_runs", "origin IN ('model','user_edit')"
    )
    op.create_check_constraint(
        "ck_compilation_ancestry",
        "kb_compilation_runs",
        "(origin = 'model' AND parent_run_id IS NULL) OR (origin = 'user_edit' AND parent_run_id IS NOT NULL)",
    )
    op.create_unique_constraint(
        "uq_ocr_text_scope", "ocr_text_versions", ["id", "run_id", "workspace_id", "collection_id"]
    )
    op.add_column("kb_compilation_inputs", sa.Column("text_version_id", sa.String(64)))
    op.add_column("kb_compilation_inputs", sa.Column("original_canonical_sha256", sa.String(64)))
    op.create_foreign_key(
        "fk_compilation_input_text",
        "kb_compilation_inputs",
        "ocr_text_versions",
        ["text_version_id", "ocr_run_id", "workspace_id", "collection_id"],
        ["id", "run_id", "workspace_id", "collection_id"],
        ondelete="RESTRICT",
    )

    op.execute("""
CREATE TABLE kb_compilation_review_jobs (
	compilation_run_id VARCHAR(64) NOT NULL, 
	workspace_id VARCHAR(64) NOT NULL, 
	collection_id VARCHAR(64) NOT NULL, 
	created_by VARCHAR(200) NOT NULL, 
	config JSONB NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	review_id VARCHAR(64), 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	dispatched_at TIMESTAMP WITH TIME ZONE, 
	started_at TIMESTAMP WITH TIME ZONE, 
	finished_at TIMESTAMP WITH TIME ZONE, 
	lease_expires_at TIMESTAMP WITH TIME ZONE, 
	worker_id VARCHAR(120), 
	error_code VARCHAR(64), 
	PRIMARY KEY (compilation_run_id), 
	CONSTRAINT fk_compilation_review_job_scope FOREIGN KEY(compilation_run_id, workspace_id, collection_id) REFERENCES kb_compilation_runs (id, workspace_id, collection_id) ON DELETE RESTRICT, 
	CONSTRAINT ck_compilation_review_job_status CHECK (status IN ('queued','running','completed','failed','uncertain')), 
	FOREIGN KEY(review_id) REFERENCES kb_compilation_reviews (id) ON DELETE RESTRICT
)
""")
    op.execute(
        "CREATE INDEX ix_kb_compilation_review_jobs_status ON kb_compilation_review_jobs (status)"
    )

    op.execute("""
CREATE TABLE kb_compilation_edit_previews (
	id VARCHAR(64) NOT NULL, 
	compilation_run_id VARCHAR(64) NOT NULL, 
	workspace_id VARCHAR(64) NOT NULL, 
	collection_id VARCHAR(64) NOT NULL, 
	created_by VARCHAR(200) NOT NULL, 
	bundle_sha256 VARCHAR(64) NOT NULL, 
	expected_edit_count INTEGER NOT NULL, 
	content JSONB NOT NULL, 
	reason VARCHAR(2000) NOT NULL, 
	review_id VARCHAR(64), 
	report_sha256 VARCHAR(64), 
	preview_sha256 VARCHAR(64) NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	child_run_id VARCHAR(64), 
	PRIMARY KEY (id), 
	CONSTRAINT fk_compilation_edit_scope FOREIGN KEY(compilation_run_id, workspace_id, collection_id) REFERENCES kb_compilation_runs (id, workspace_id, collection_id) ON DELETE RESTRICT, 
	FOREIGN KEY(review_id) REFERENCES kb_compilation_reviews (id) ON DELETE RESTRICT, 
	UNIQUE (child_run_id), 
	FOREIGN KEY(child_run_id) REFERENCES kb_compilation_runs (id) ON DELETE RESTRICT
)
""")
    op.execute(
        "CREATE INDEX ix_kb_compilation_edit_previews_compilation_run_id ON kb_compilation_edit_previews (compilation_run_id)"
    )


def downgrade() -> None:
    raise RuntimeError("Compiler workflow evidence must be preserved; downgrade is disabled.")
