"""Durable Compiler drafts bound to immutable OCR evidence (v1 ownership only)."""

from __future__ import annotations

import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

from alembic import op

revision = "0007_compilation"
down_revision = "0006_ocr_processing"
branch_labels = None
depends_on = None


def upgrade() -> None:
    existing = set(sa.inspect(op.get_bind()).get_table_names())
    if existing.intersection(
        {"kb_compilation_runs", "kb_compilation_inputs", "kb_compilation_artifacts"}
    ):
        raise RuntimeError("Compiler tables already exist outside the v1 migration history.")
    op.create_unique_constraint(
        "uq_ocr_run_scope", "ocr_processing_runs", ["id", "workspace_id", "collection_id"]
    )
    op.create_table(
        "kb_compilation_runs",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("workspace_id", sa.String(64), nullable=False),
        sa.Column("collection_id", sa.String(64), nullable=False),
        sa.Column("generation", sa.Integer(), nullable=False),
        sa.Column("topic", sa.String(2000), nullable=False),
        sa.Column("status", sa.String(16), nullable=False),
        sa.Column("requested_by", sa.String(200), nullable=False),
        sa.Column("idempotency_key", sa.String(128), nullable=False),
        sa.Column("request_hash", sa.String(64), nullable=False),
        sa.Column("input_sha256", sa.String(64), nullable=False),
        sa.Column(
            "provider_id",
            sa.String(64),
            sa.ForeignKey("providers.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column("config", postgresql.JSONB(), nullable=False),
        sa.Column("requested_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("dispatched_at", sa.DateTime(timezone=True)),
        sa.Column("started_at", sa.DateTime(timezone=True)),
        sa.Column("finished_at", sa.DateTime(timezone=True)),
        sa.Column("request_started_at", sa.DateTime(timezone=True)),
        sa.Column("attempt_count", sa.Integer(), nullable=False),
        sa.Column("worker_id", sa.String(120)),
        sa.Column("lease_expires_at", sa.DateTime(timezone=True)),
        sa.Column(
            "usage_id", sa.String(64), sa.ForeignKey("model_usage_records.id", ondelete="RESTRICT")
        ),
        sa.Column("usage_tokens", sa.Integer()),
        sa.Column("error_code", sa.String(64)),
        sa.ForeignKeyConstraint(
            ["collection_id", "workspace_id"],
            ["kb_collections.id", "kb_collections.workspace_id"],
            ondelete="RESTRICT",
            name="fk_compilation_collection",
        ),
        sa.UniqueConstraint("id", "workspace_id", "collection_id", name="uq_compilation_scope"),
        sa.UniqueConstraint("collection_id", "generation", name="uq_compilation_generation"),
        sa.UniqueConstraint(
            "workspace_id", "requested_by", "idempotency_key", name="uq_compilation_request"
        ),
        sa.CheckConstraint(
            "status IN ('queued','running','completed','failed','uncertain')",
            name="ck_compilation_status",
        ),
        sa.CheckConstraint(
            "generation >= 1 AND attempt_count >= 0", name="ck_compilation_counters"
        ),
    )
    for field in ("workspace_id", "collection_id", "status"):
        op.create_index(f"ix_kb_compilation_runs_{field}", "kb_compilation_runs", [field])
    op.create_table(
        "kb_compilation_inputs",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("run_id", sa.String(64), nullable=False),
        sa.Column("workspace_id", sa.String(64), nullable=False),
        sa.Column("collection_id", sa.String(64), nullable=False),
        sa.Column("ocr_run_id", sa.String(64), nullable=False),
        sa.Column("canonical_sha256", sa.String(64), nullable=False),
        sa.Column("manifest_sha256", sa.String(64), nullable=False),
        sa.ForeignKeyConstraint(
            ["run_id", "workspace_id", "collection_id"],
            [
                "kb_compilation_runs.id",
                "kb_compilation_runs.workspace_id",
                "kb_compilation_runs.collection_id",
            ],
            ondelete="CASCADE",
            name="fk_compilation_input_run",
        ),
        sa.ForeignKeyConstraint(
            ["ocr_run_id", "workspace_id", "collection_id"],
            [
                "ocr_processing_runs.id",
                "ocr_processing_runs.workspace_id",
                "ocr_processing_runs.collection_id",
            ],
            ondelete="RESTRICT",
            name="fk_compilation_input_ocr",
        ),
        sa.UniqueConstraint("run_id", "ocr_run_id", name="uq_compilation_input_ocr"),
    )
    op.create_index("ix_kb_compilation_inputs_run_id", "kb_compilation_inputs", ["run_id"])
    op.create_table(
        "kb_compilation_artifacts",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column(
            "run_id",
            sa.String(64),
            sa.ForeignKey("kb_compilation_runs.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("kind", sa.String(24), nullable=False),
        sa.Column("blob_key", sa.String(512), nullable=False),
        sa.Column("sha256", sa.String(64), nullable=False),
        sa.Column("size_bytes", sa.Integer(), nullable=False),
        sa.Column("content_type", sa.String(120), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("run_id", "kind", name="uq_compilation_artifact_kind"),
        sa.CheckConstraint(
            "kind IN ('input_snapshot','raw_response','draft_json','markdown')",
            name="ck_compilation_artifact_kind",
        ),
        sa.CheckConstraint(
            "size_bytes >= 0 AND char_length(sha256) = 64", name="ck_compilation_artifact_integrity"
        ),
    )
    op.create_index("ix_kb_compilation_artifacts_run_id", "kb_compilation_artifacts", ["run_id"])


def downgrade() -> None:
    raise RuntimeError(
        "Compiler evidence must be preserved; downgrade requires an explicit rollback plan."
    )
