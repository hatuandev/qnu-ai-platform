"""BackendV1 baseline: no DDL, no legacy stamping.

The legacy backend keeps owning every existing table until cutover. This
revision only creates the v1 version table so later v1 revisions have a root.
"""

from __future__ import annotations

revision = "0001_baseline"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Intentionally empty: v1 adds no schema at baseline."""


def downgrade() -> None:
    """Intentionally empty."""
