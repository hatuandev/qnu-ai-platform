"""Independent compiler reviews with pinned source/draft hashes and artifacts."""

import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

from alembic import op

revision = "0012_compiler_review"
down_revision = "0011_ocr_text_review"
branch_labels = None
depends_on = None


def upgrade() -> None:
    existing = set(sa.inspect(op.get_bind()).get_table_names())
    if existing.intersection({"kb_compilation_reviews", "kb_compilation_review_artifacts"}):
        raise RuntimeError("Compiler review tables already exist outside v1 history.")
    op.create_table(
        "kb_compilation_reviews",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("compilation_run_id", sa.String(64), nullable=False),
        sa.Column("workspace_id", sa.String(64), nullable=False),
        sa.Column("collection_id", sa.String(64), nullable=False),
        sa.Column("created_by", sa.String(200), nullable=False),
        sa.Column("idempotency_key", sa.String(128), nullable=False),
        sa.Column("request_hash", sa.String(64), nullable=False),
        sa.Column("status", sa.String(16), nullable=False),
        sa.Column("verdict", sa.String(32)),
        sa.Column(
            "provider_id",
            sa.String(64),
            sa.ForeignKey("providers.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column("input_sha256", sa.String(64), nullable=False),
        sa.Column("draft_sha256", sa.String(64), nullable=False),
        sa.Column("bundle_sha256", sa.String(64), nullable=False),
        sa.Column("trace", postgresql.JSONB(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("finished_at", sa.DateTime(timezone=True)),
        sa.Column("request_started_at", sa.DateTime(timezone=True)),
        sa.Column(
            "usage_id", sa.String(64), sa.ForeignKey("model_usage_records.id", ondelete="RESTRICT")
        ),
        sa.Column("usage_tokens", sa.Integer()),
        sa.Column("error_code", sa.String(64)),
        sa.ForeignKeyConstraint(
            ["compilation_run_id", "workspace_id", "collection_id"],
            [
                "kb_compilation_runs.id",
                "kb_compilation_runs.workspace_id",
                "kb_compilation_runs.collection_id",
            ],
            ondelete="RESTRICT",
            name="fk_compilation_review_scope",
        ),
        sa.UniqueConstraint(
            "workspace_id", "created_by", "idempotency_key", name="uq_compilation_review_request"
        ),
        sa.CheckConstraint(
            "status IN ('running','completed','failed','uncertain')",
            name="ck_compilation_review_status",
        ),
        sa.CheckConstraint(
            "verdict IS NULL OR verdict IN ('needs_attention','no_issues_detected')",
            name="ck_compilation_review_verdict",
        ),
    )
    op.create_index(
        "ix_kb_compilation_reviews_compilation_run_id",
        "kb_compilation_reviews",
        ["compilation_run_id"],
    )
    op.create_index(
        "ix_kb_compilation_reviews_workspace_id", "kb_compilation_reviews", ["workspace_id"]
    )
    op.create_table(
        "kb_compilation_review_artifacts",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column(
            "review_id",
            sa.String(64),
            sa.ForeignKey("kb_compilation_reviews.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column("kind", sa.String(24), nullable=False),
        sa.Column("blob_key", sa.String(512), nullable=False),
        sa.Column("sha256", sa.String(64), nullable=False),
        sa.Column("size_bytes", sa.Integer(), nullable=False),
        sa.Column("content_type", sa.String(120), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("review_id", "kind", name="uq_compilation_review_artifact"),
        sa.CheckConstraint(
            "kind IN ('input_snapshot','raw_response','report_json','markdown')",
            name="ck_compilation_review_artifact_kind",
        ),
        sa.CheckConstraint(
            "size_bytes >= 0 AND char_length(sha256) = 64",
            name="ck_compilation_review_artifact_hash",
        ),
    )
    op.create_index(
        "ix_kb_compilation_review_artifacts_review_id",
        "kb_compilation_review_artifacts",
        ["review_id"],
    )


def downgrade() -> None:
    raise RuntimeError("Compiler review evidence must be preserved; downgrade is disabled.")
