"""Knowledge collections, sources and immutable file revisions (backendV1-owned).

Table names use the ``kb_`` prefix: the legacy ``knowledge_*`` tables stay owned by
``backend/`` and are never altered here.
"""

from __future__ import annotations

import sqlalchemy as sa

from alembic import context, op

revision = "0005_knowledge_collections"
down_revision = "0004_workspace_model_policy"
branch_labels = None
depends_on = None

V1_OWNED = ("kb_collections", "kb_sources", "kb_source_revisions", "kb_upload_requests")


def _existing_tables() -> set[str]:
    if context.is_offline_mode():
        return set()
    return set(sa.inspect(op.get_bind()).get_table_names())


def upgrade() -> None:
    existing = _existing_tables()
    if existing.intersection(V1_OWNED):
        raise RuntimeError("Knowledge tables already exist outside the v1 migration history.")

    op.create_table(
        "kb_collections",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column(
            "workspace_id",
            sa.String(64),
            sa.ForeignKey("workspaces.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("created_by", sa.String(200), nullable=False),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()
        ),
        sa.UniqueConstraint("workspace_id", "name", name="uq_kb_collection_name"),
        sa.UniqueConstraint("id", "workspace_id", name="uq_kb_collection_scope"),
    )
    op.create_index("ix_kb_collections_workspace_id", "kb_collections", ["workspace_id"])

    op.create_table(
        "kb_sources",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("workspace_id", sa.String(64), nullable=False),
        sa.Column("collection_id", sa.String(64), nullable=False),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("status", sa.String(32), nullable=False, server_default="stored"),
        sa.Column("latest_revision_no", sa.Integer(), nullable=False),
        sa.Column("created_by", sa.String(200), nullable=False),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()
        ),
        sa.ForeignKeyConstraint(
            ["collection_id", "workspace_id"],
            ["kb_collections.id", "kb_collections.workspace_id"],
            name="fk_kb_source_collection",
            ondelete="CASCADE",
        ),
        sa.UniqueConstraint("id", "collection_id", "workspace_id", name="uq_kb_source_scope"),
        sa.CheckConstraint("status IN ('stored')", name="ck_kb_source_status"),
        sa.CheckConstraint("latest_revision_no >= 1", name="ck_kb_source_latest_revision"),
    )
    op.create_index("ix_kb_sources_workspace_id", "kb_sources", ["workspace_id"])
    op.create_index("ix_kb_sources_collection_id", "kb_sources", ["collection_id"])

    op.create_table(
        "kb_source_revisions",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("workspace_id", sa.String(64), nullable=False),
        sa.Column("collection_id", sa.String(64), nullable=False),
        sa.Column("source_id", sa.String(64), nullable=False),
        sa.Column("revision_no", sa.Integer(), nullable=False),
        sa.Column("file_name", sa.String(255), nullable=False),
        sa.Column("content_type", sa.String(120), nullable=False),
        sa.Column("size_bytes", sa.Integer(), nullable=False),
        sa.Column("sha256", sa.String(64), nullable=False),
        sa.Column("storage_key", sa.String(512), nullable=False),
        sa.Column("created_by", sa.String(200), nullable=False),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()
        ),
        sa.ForeignKeyConstraint(
            ["source_id", "collection_id", "workspace_id"],
            ["kb_sources.id", "kb_sources.collection_id", "kb_sources.workspace_id"],
            name="fk_kb_revision_source",
            ondelete="CASCADE",
        ),
        sa.UniqueConstraint("source_id", "revision_no", name="uq_kb_revision_no"),
        sa.UniqueConstraint("collection_id", "sha256", name="uq_kb_revision_content"),
        sa.UniqueConstraint("storage_key", name="uq_kb_revision_storage_key"),
        sa.CheckConstraint("revision_no >= 1", name="ck_kb_revision_no"),
        sa.CheckConstraint("size_bytes > 0", name="ck_kb_revision_size"),
        sa.CheckConstraint("char_length(sha256) = 64", name="ck_kb_revision_sha256"),
    )

    op.create_table(
        "kb_upload_requests",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("workspace_id", sa.String(64), nullable=False),
        sa.Column("collection_id", sa.String(64), nullable=False),
        sa.Column("actor_ref", sa.String(200), nullable=False),
        sa.Column("idempotency_key", sa.String(128), nullable=False),
        sa.Column("request_hash", sa.String(64), nullable=False),
        sa.Column("source_id", sa.String(64), nullable=False),
        sa.Column("revision_id", sa.String(64), nullable=False),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()
        ),
        sa.UniqueConstraint(
            "workspace_id", "actor_ref", "idempotency_key", name="uq_kb_upload_idempotency"
        ),
        sa.CheckConstraint("char_length(request_hash) = 64", name="ck_kb_upload_request_hash"),
    )


def downgrade() -> None:
    """Keep stored evidence: sources and revisions are not dropped by a downgrade."""
    raise RuntimeError(
        "Knowledge evidence must be preserved; downgrade requires an explicit rollback plan."
    )
