"""Operations approvals and evidence archive receipts; never migrates legacy tables."""

import sqlalchemy as sa

from alembic import op

revision = "0014_operations"
down_revision = "0013_compiler_workflow"
branch_labels = None
depends_on = None


def upgrade() -> None:
    if set(sa.inspect(op.get_bind()).get_table_names()).intersection(
        {"ops_actions", "ops_evidence_backups"}
    ):
        raise RuntimeError("Operations tables already exist outside v1 history.")

    op.execute("""
CREATE TABLE ops_actions (
	id VARCHAR(64) NOT NULL, 
	workspace_id VARCHAR(64) NOT NULL, 
	actor_ref VARCHAR(200) NOT NULL, 
	kind VARCHAR(24) NOT NULL, 
	job_id VARCHAR(64) NOT NULL, 
	action VARCHAR(24) NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	reason VARCHAR(2000) NOT NULL, 
	state_sha256 VARCHAR(64) NOT NULL, 
	preview_sha256 VARCHAR(64) NOT NULL, 
	idempotency_key VARCHAR(128), 
	request_hash VARCHAR(64), 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	dispatched_at TIMESTAMP WITH TIME ZONE, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_ops_action_request UNIQUE (workspace_id, actor_ref, idempotency_key), 
	CONSTRAINT ck_ops_action_status CHECK (status IN ('preview','pending','dispatched','superseded')), 
	CONSTRAINT ck_ops_action_type CHECK (action IN ('dispatch','delete_backup')), 
	FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT
)
""")
    op.execute("CREATE INDEX ix_ops_actions_workspace_id ON ops_actions (workspace_id)")

    op.execute("""
CREATE TABLE ops_evidence_backups (
	id VARCHAR(64) NOT NULL, 
	workspace_id VARCHAR(64) NOT NULL, 
	created_by VARCHAR(200) NOT NULL, 
	idempotency_key VARCHAR(128) NOT NULL, 
	request_hash VARCHAR(64) NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	retain_until TIMESTAMP WITH TIME ZONE, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	dispatched_at TIMESTAMP WITH TIME ZONE, 
	started_at TIMESTAMP WITH TIME ZONE, 
	finished_at TIMESTAMP WITH TIME ZONE, 
	lease_expires_at TIMESTAMP WITH TIME ZONE, 
	worker_id VARCHAR(120), 
	blob_key VARCHAR(512), 
	sha256 VARCHAR(64), 
	size_bytes INTEGER, 
	manifest JSONB, 
	error_code VARCHAR(64), 
	delete_action_id VARCHAR(64), 
	PRIMARY KEY (id), 
	CONSTRAINT uq_ops_backup_request UNIQUE (workspace_id, created_by, idempotency_key), 
	CONSTRAINT ck_ops_backup_status CHECK (status IN ('queued','running','completed','failed','uncertain','deleting','deleted')), 
	FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT, 
	FOREIGN KEY(delete_action_id) REFERENCES ops_actions (id) ON DELETE RESTRICT
)
""")
    op.execute(
        "CREATE INDEX ix_ops_evidence_backups_workspace_id ON ops_evidence_backups (workspace_id)"
    )


def downgrade() -> None:
    raise RuntimeError("Operations evidence must be preserved; downgrade is disabled.")
