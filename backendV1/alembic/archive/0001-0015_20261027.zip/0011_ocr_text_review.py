"""Saved OCR text revisions and spelling inspections; original artifacts untouched."""

import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

from alembic import op

revision = "0011_ocr_text_review"
down_revision = "0010_conversations"
branch_labels = None
depends_on = None


def common_columns():
    return [
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("run_id", sa.String(64), nullable=False),
        sa.Column("workspace_id", sa.String(64), nullable=False),
        sa.Column("collection_id", sa.String(64), nullable=False),
        sa.Column("version", sa.Integer(), nullable=False),
        sa.Column("canonical_sha256", sa.String(64), nullable=False),
        sa.Column("created_by", sa.String(200), nullable=False),
        sa.Column("idempotency_key", sa.String(128), nullable=False),
        sa.Column("request_hash", sa.String(64), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    ]


def scope(name):
    return sa.ForeignKeyConstraint(
        ["run_id", "workspace_id", "collection_id"],
        [
            "ocr_processing_runs.id",
            "ocr_processing_runs.workspace_id",
            "ocr_processing_runs.collection_id",
        ],
        ondelete="RESTRICT",
        name=name,
    )


def upgrade() -> None:
    existing = set(sa.inspect(op.get_bind()).get_table_names())
    if existing.intersection({"ocr_text_versions", "ocr_spelling_runs"}):
        raise RuntimeError("OCR text tables already exist outside v1 history.")
    op.create_table(
        "ocr_text_versions",
        *common_columns(),
        sa.Column("original_sha256", sa.String(64), nullable=False),
        sa.Column("markdown_sha256", sa.String(64), nullable=False),
        sa.Column("document_key", sa.String(512), nullable=False),
        sa.Column("markdown_key", sa.String(512), nullable=False),
        sa.Column("changes", postgresql.JSONB(), nullable=False),
        scope("fk_ocr_text_run"),
        sa.UniqueConstraint("run_id", "version", name="uq_ocr_text_version"),
        sa.UniqueConstraint(
            "workspace_id", "created_by", "idempotency_key", name="uq_ocr_text_request"
        ),
        sa.CheckConstraint("version > 0", name="ck_ocr_text_version"),
    )
    op.create_index("ix_ocr_text_versions_run_id", "ocr_text_versions", ["run_id"])
    op.create_table(
        "ocr_spelling_runs",
        *common_columns(),
        sa.Column("status", sa.String(16), nullable=False),
        sa.Column("checked_evidence_ids", postgresql.JSONB(), nullable=False),
        sa.Column("suggestions", postgresql.JSONB(), nullable=False),
        sa.Column("trace", postgresql.JSONB(), nullable=False),
        sa.Column("usage_id", sa.String(64), nullable=True),
        sa.Column("error_code", sa.String(64), nullable=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        scope("fk_ocr_spelling_run"),
        sa.UniqueConstraint(
            "workspace_id", "created_by", "idempotency_key", name="uq_ocr_spelling_request"
        ),
        sa.CheckConstraint(
            "status IN ('running','completed','failed','uncertain')", name="ck_ocr_spelling_status"
        ),
    )
    op.create_index("ix_ocr_spelling_runs_run_id", "ocr_spelling_runs", ["run_id"])


def downgrade() -> None:
    raise RuntimeError("OCR text evidence must be preserved; downgrade is disabled.")
