"""ModelOps tables owned by backendV1 (distinct from the legacy names)."""

from __future__ import annotations

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB

from alembic import context, op

revision = "0003_modelops"
down_revision = "0002_workspaces"
branch_labels = None
depends_on = None


def _existing_tables() -> set[str]:
    if context.is_offline_mode():
        return set()
    return set(sa.inspect(op.get_bind()).get_table_names())


def upgrade() -> None:
    existing = _existing_tables()
    if existing.intersection(
        {
            "providers",
            "provider_keys",
            "provider_key_audits",
            "model_defaults",
            "workspace_allowed_providers",
        }
    ):
        raise RuntimeError("ModelOps tables already exist outside the v1 migration history.")

    if "providers" not in existing:
        op.create_table(
            "providers",
            sa.Column("id", sa.String(64), primary_key=True),
            sa.Column("name", sa.String(255), nullable=False, unique=True),
            sa.Column("provider_type", sa.String(32), nullable=False),
            sa.Column("base_url", sa.String(1024), nullable=False),
            sa.Column("model_name", sa.String(200), nullable=False),
            sa.Column("capabilities", JSONB(), nullable=False, server_default="[]"),
            sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
            sa.Column("priority", sa.Integer(), nullable=False, server_default="5"),
            sa.Column("timeout_seconds", sa.Integer(), nullable=False, server_default="30"),
            sa.Column("extra_config", JSONB(), nullable=False, server_default="{}"),
            sa.Column("created_by", sa.String(200), nullable=True),
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=sa.func.now(),
            ),
            sa.Column(
                "updated_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=sa.func.now(),
            ),
            sa.CheckConstraint(
                "provider_type IN ('openai_compatible','gemini','local','nemotron','paddleocr')",
                name="ck_provider_type",
            ),
        )
        op.create_index("ix_providers_is_active", "providers", ["is_active"])

    if "provider_keys" not in existing:
        op.create_table(
            "provider_keys",
            sa.Column("id", sa.String(64), primary_key=True),
            sa.Column(
                "provider_id",
                sa.String(64),
                sa.ForeignKey("providers.id", ondelete="CASCADE"),
                nullable=False,
            ),
            sa.Column("name", sa.String(120), nullable=False),
            sa.Column("secret_encrypted", sa.Text(), nullable=False),
            sa.Column("masked_hint", sa.String(16), nullable=False),
            sa.Column("status", sa.String(32), nullable=False, server_default="active"),
            sa.Column("priority", sa.Integer(), nullable=False, server_default="5"),
            sa.Column("lease_until", sa.DateTime(timezone=True), nullable=True),
            sa.Column("cooldown_until", sa.DateTime(timezone=True), nullable=True),
            sa.Column("consecutive_failures", sa.Integer(), nullable=False, server_default="0"),
            sa.Column("created_by", sa.String(200), nullable=True),
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=sa.func.now(),
            ),
            sa.Column(
                "updated_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=sa.func.now(),
            ),
            sa.CheckConstraint("status IN ('active','revoked')", name="ck_provider_key_status"),
        )
        op.create_index("ix_provider_keys_provider_id", "provider_keys", ["provider_id"])
        op.create_index("ix_provider_keys_status", "provider_keys", ["status"])

    if "provider_key_audits" not in existing:
        op.create_table(
            "provider_key_audits",
            sa.Column("id", sa.String(64), primary_key=True),
            sa.Column(
                "provider_id",
                sa.String(64),
                sa.ForeignKey("providers.id", ondelete="CASCADE"),
                nullable=False,
            ),
            sa.Column("key_id", sa.String(64), nullable=True),
            sa.Column("actor_ref", sa.String(200), nullable=True),
            sa.Column("action", sa.String(32), nullable=False),
            sa.Column("reason", sa.String(512), nullable=True),
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=sa.func.now(),
            ),
        )
        op.create_index(
            "ix_provider_key_audits_provider_id", "provider_key_audits", ["provider_id"]
        )
        op.create_index("ix_provider_key_audits_key_id", "provider_key_audits", ["key_id"])

    if "model_defaults" not in existing:
        op.create_table(
            "model_defaults",
            sa.Column("id", sa.String(32), primary_key=True),
            sa.Column("chat_provider_id", sa.String(64), nullable=True),
            sa.Column("chat_model", sa.String(200), nullable=True),
            sa.Column("embedding_provider_id", sa.String(64), nullable=True),
            sa.Column("embedding_model", sa.String(200), nullable=True),
            sa.Column("rerank_provider_id", sa.String(64), nullable=True),
            sa.Column("rerank_model", sa.String(200), nullable=True),
            sa.Column("ocr_provider_id", sa.String(64), nullable=True),
            sa.Column("ocr_model", sa.String(200), nullable=True),
            sa.Column("updated_by", sa.String(200), nullable=True),
            sa.Column(
                "updated_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=sa.func.now(),
            ),
        )

    if "workspace_allowed_providers" not in existing:
        op.create_table(
            "workspace_allowed_providers",
            sa.Column(
                "workspace_id",
                sa.String(64),
                sa.ForeignKey("workspaces.id", ondelete="CASCADE"),
                primary_key=True,
            ),
            sa.Column(
                "provider_id",
                sa.String(64),
                sa.ForeignKey("providers.id", ondelete="CASCADE"),
                primary_key=True,
            ),
            sa.Column("is_default", sa.Boolean(), nullable=False, server_default=sa.false()),
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=sa.func.now(),
            ),
        )
        op.create_index(
            "ix_workspace_allowed_providers_provider_id",
            "workspace_allowed_providers",
            ["provider_id"],
        )


def downgrade() -> None:
    """Keep credential audit history; credential rows are never dropped silently."""
