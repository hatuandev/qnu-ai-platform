"""Dense generations, publication bindings and chunks (backendV1 ownership)."""

from __future__ import annotations

import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

from alembic import op

revision = "0009_dense_index"
down_revision = "0008_publication"
branch_labels = None
depends_on = None


def upgrade() -> None:
    existing = set(sa.inspect(op.get_bind()).get_table_names())
    if existing.intersection({"kb_index_runs", "kb_index_inputs", "kb_index_chunks"}):
        raise RuntimeError("Index tables already exist outside the v1 migration history.")
    op.create_unique_constraint(
        "uq_publication_decision_scope",
        "kb_publication_decisions",
        ["id", "version_id", "document_id", "workspace_id", "collection_id"],
    )
    op.create_table(
        "kb_index_runs",
        sa.Column("id", sa.String(length=64), nullable=False),
        sa.Column("workspace_id", sa.String(length=64), nullable=False),
        sa.Column("collection_id", sa.String(length=64), nullable=False),
        sa.Column("generation", sa.Integer(), nullable=False),
        sa.Column("status", sa.String(length=16), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False),
        sa.Column("provider_id", sa.String(length=64), nullable=False),
        sa.Column("dimension", sa.Integer(), nullable=False),
        sa.Column("vector_collection", sa.String(length=120), nullable=False),
        sa.Column("config", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("input_sha256", sa.String(length=64), nullable=False),
        sa.Column("requested_by", sa.String(length=200), nullable=False),
        sa.Column("idempotency_key", sa.String(length=128), nullable=False),
        sa.Column("request_hash", sa.String(length=64), nullable=False),
        sa.Column("requested_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("dispatched_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("worker_id", sa.String(length=120), nullable=True),
        sa.Column("lease_expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("attempt_count", sa.Integer(), nullable=False),
        sa.Column("error_code", sa.String(length=64), nullable=True),
        sa.Column("chunks_total", sa.Integer(), nullable=False),
        sa.Column("pending_batch", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("batch_receipts", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("manifest_key", sa.String(length=512), nullable=True),
        sa.Column("manifest_sha256", sa.String(length=64), nullable=True),
        sa.CheckConstraint(
            "NOT is_active OR status = 'completed'", name="ck_index_active_completed"
        ),
        sa.CheckConstraint(
            "status IN ('queued','running','completed','failed','uncertain')",
            name="ck_index_status",
        ),
        sa.CheckConstraint(
            "generation >= 1 AND dimension > 0 AND attempt_count >= 0", name="ck_index_counters"
        ),
        sa.ForeignKeyConstraint(
            ["collection_id", "workspace_id"],
            ["kb_collections.id", "kb_collections.workspace_id"],
            name="fk_index_run_collection",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(["provider_id"], ["providers.id"], ondelete="RESTRICT"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("collection_id", "generation", name="uq_index_generation"),
        sa.UniqueConstraint("id", "workspace_id", "collection_id", name="uq_index_run_scope"),
        sa.UniqueConstraint("vector_collection"),
        sa.UniqueConstraint(
            "workspace_id", "requested_by", "idempotency_key", name="uq_index_request"
        ),
    )
    op.create_index(
        "uq_index_active",
        "kb_index_runs",
        ["collection_id"],
        unique=True,
        postgresql_where=sa.text("is_active = true"),
    )
    op.create_index(
        "uq_index_working",
        "kb_index_runs",
        ["collection_id"],
        unique=True,
        postgresql_where=sa.text("status IN ('queued','running')"),
    )
    op.create_table(
        "kb_index_inputs",
        sa.Column("id", sa.String(length=64), nullable=False),
        sa.Column("run_id", sa.String(length=64), nullable=False),
        sa.Column("workspace_id", sa.String(length=64), nullable=False),
        sa.Column("collection_id", sa.String(length=64), nullable=False),
        sa.Column("document_id", sa.String(length=64), nullable=False),
        sa.Column("version_id", sa.String(length=64), nullable=False),
        sa.Column("publication_decision_id", sa.String(length=64), nullable=False),
        sa.Column("bundle_sha256", sa.String(length=64), nullable=False),
        sa.Column("version_state", sa.Integer(), nullable=False),
        sa.ForeignKeyConstraint(
            [
                "publication_decision_id",
                "version_id",
                "document_id",
                "workspace_id",
                "collection_id",
            ],
            [
                "kb_publication_decisions.id",
                "kb_publication_decisions.version_id",
                "kb_publication_decisions.document_id",
                "kb_publication_decisions.workspace_id",
                "kb_publication_decisions.collection_id",
            ],
            name="fk_index_input_publication",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["run_id", "workspace_id", "collection_id"],
            ["kb_index_runs.id", "kb_index_runs.workspace_id", "kb_index_runs.collection_id"],
            name="fk_index_input_run",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "id", "run_id", "workspace_id", "collection_id", name="uq_index_input_scope"
        ),
        sa.UniqueConstraint("run_id", "document_id", name="uq_index_input_document"),
    )
    op.create_index(op.f("ix_kb_index_inputs_run_id"), "kb_index_inputs", ["run_id"], unique=False)
    op.create_table(
        "kb_index_chunks",
        sa.Column("id", sa.String(length=64), nullable=False),
        sa.Column("input_id", sa.String(length=64), nullable=False),
        sa.Column("run_id", sa.String(length=64), nullable=False),
        sa.Column("workspace_id", sa.String(length=64), nullable=False),
        sa.Column("collection_id", sa.String(length=64), nullable=False),
        sa.Column("point_id", sa.String(length=36), nullable=False),
        sa.Column("ordinal", sa.Integer(), nullable=False),
        sa.Column("kind", sa.String(length=16), nullable=False),
        sa.Column("text", sa.Text(), nullable=False),
        sa.Column("text_sha256", sa.String(length=64), nullable=False),
        sa.Column("citations", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("structure", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("vector", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.CheckConstraint("ordinal >= 0", name="ck_index_chunk_ordinal"),
        sa.ForeignKeyConstraint(
            ["input_id", "run_id", "workspace_id", "collection_id"],
            [
                "kb_index_inputs.id",
                "kb_index_inputs.run_id",
                "kb_index_inputs.workspace_id",
                "kb_index_inputs.collection_id",
            ],
            name="fk_index_chunk_input",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("point_id", name="uq_index_chunk_point"),
        sa.UniqueConstraint("run_id", "ordinal", name="uq_index_chunk_ordinal"),
    )
    op.create_index(op.f("ix_kb_index_chunks_run_id"), "kb_index_chunks", ["run_id"], unique=False)


def downgrade() -> None:
    raise RuntimeError(
        "Index evidence must be preserved; downgrade requires an explicit rollback plan."
    )
